import java.util.Scanner;

/**
 * A simple console-based currency converter.
 * This program converts a given amount in USD to EUR, INR, or JPY
 * using fixed exchange rates.
 */
public class CurrencyConverter {

    public static void main(String[] args) {

        // --- Fixed Exchange Rates (as of a certain date) ---
        // 1 USD to other currencies
        final double USD_TO_EUR_RATE = 0.93; // 1 USD = 0.93 EUR
        final double USD_TO_INR_RATE = 83.45; // 1 USD = 83.45 INR
        final double USD_TO_JPY_RATE = 157.33; // 1 USD = 157.33 JPY

        // --- User Input ---
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Simple Currency Converter!");
        System.out.print("Enter the amount in USD to convert: $");
        
        // Read the amount from the user
        double amountInUSD = scanner.nextDouble();

        System.out.println("\nSelect the currency to convert to:");
        System.out.println("1. EUR (Euro)");
        System.out.println("2. INR (Indian Rupee)");
        System.out.println("3. JPY (Japanese Yen)");
        System.out.print("Enter your choice (1-3): ");
        
        // Read the user's choice
        int choice = scanner.nextInt();
        
        // --- Conversion Logic & Output ---
        double convertedAmount = 0.0;
        String targetCurrency = "";

        switch (choice) {
            case 1:
                convertedAmount = amountInUSD * USD_TO_EUR_RATE;
                targetCurrency = "EUR";
                System.out.printf("\n$%.2f USD is equivalent to %.2f %s.\n", amountInUSD, convertedAmount, targetCurrency);
                break;
            case 2:
                convertedAmount = amountInUSD * USD_TO_INR_RATE;
                targetCurrency = "INR";
                System.out.printf("\n$%.2f USD is equivalent to %.2f %s.\n", amountInUSD, convertedAmount, targetCurrency);
                break;
            case 3:
                convertedAmount = amountInUSD * USD_TO_JPY_RATE;
                targetCurrency = "JPY";
                System.out.printf("\n$%.2f USD is equivalent to %.2f %s.\n", amountInUSD, convertedAmount, targetCurrency);
                break;
            default:
                System.out.println("\nInvalid choice. Please run the program again and select a number from 1 to 3.");
                break;
        }

        // Close the scanner to prevent resource leaks
        scanner.close();
    }
}