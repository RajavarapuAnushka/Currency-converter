# Currency-Converter
This is a simple currency converter which converts dollars to euros and rupees
